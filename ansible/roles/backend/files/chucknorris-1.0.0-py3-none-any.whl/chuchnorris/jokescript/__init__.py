class CollectorBase():
    def run(self):
        raise NotImplementedError('sub classes should implement the run method')