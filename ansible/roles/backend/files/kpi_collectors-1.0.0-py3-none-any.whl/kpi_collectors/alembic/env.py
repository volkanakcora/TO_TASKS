from alembic import context

from kpi_collectors import get_config
from kpi_collectors.models import get_db_engine
from kpi_collectors.models.meta import Base


context_config = context.config
config = get_config(context_config.config_file_name)
target_metadata = Base.metadata


def run_migrations_online():
    """Run migrations in "online" mode.
    In this scenario we need to create an Engine
    and associate a connection with the context.
    """
    engine = get_db_engine(config)

    connection = engine.connect()
    context.configure(
        connection=connection, target_metadata=target_metadata, compare_type=True
    )

    try:
        with context.begin_transaction():
            context.run_migrations()
    finally:
        connection.close()


if context.is_offline_mode():
    # run_migrations_offline()
    raise NotImplementedError()
else:
    run_migrations_online()
