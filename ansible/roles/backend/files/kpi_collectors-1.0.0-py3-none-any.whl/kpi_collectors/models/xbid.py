from sqlite3 import Timestamp
from numpy import insert
from sqlalchemy import (
    Boolean,
    Column,
    DateTime,
    Index,
    Integer,
    Text,
    String,
)

from .meta import Base


class xbid(Base):
    __tablename__ = "xbiddeployment"
    id = Column(Integer, primary_key=True)

    xbidenv = Column(String(32), unique=False)
    seconds = Column(Integer)
    results = Column(Text)
    action = Column(Text)
    timestamp = Column(DateTime)
