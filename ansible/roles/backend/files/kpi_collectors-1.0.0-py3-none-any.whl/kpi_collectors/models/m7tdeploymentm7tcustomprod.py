from sqlalchemy import (
    Boolean,
    Column,
    DateTime,
    Index,
    Integer,
    Text,
    String,
)

from .meta import Base


class m7tdeploymentm7tcustomprod(Base):
    __tablename__ = "m7tdeploymentm7tcustomprod"
    id = Column(Integer, primary_key=True)

    m7env = Column(String(32), nullable=False, unique=False)
    seconds = Column(Integer)
    results = Column(Text)
    Timestamp = Column(DateTime)
    deploy_apa = Column(String)
    deploy_hap = Column(String)
    deploy_cor = Column(String)
    deploy_pmi = Column(Text)
    deploy_enq = Column(String)
    deploy_h2h = Column(String)
    deploy_mtt = Column(String)
    deploy_thr = Column(String)
    deploy_bha = Column(String)
    deploy_amq = Column(String)
    deploy_cod = Column(String)
    deploy_car = Column(String)
    deploy_sta = Column(String)
    deploy_hrv = Column(String)
    deploy_amq = Column(String)
    deploy_rep = Column(Text)
