from configparser import ConfigParser

from sqlalchemy import create_engine
from sqlalchemy.orm import configure_mappers, sessionmaker

# Make sure to import all Tables here! Otherwise alembic doesn't pick them up
from .m7tdeployment import m7tdeployment
from .m7tdeploymentseamless_new import m7tdeploymentseamless_new

from .xbid import xbid
from .sysengdata import sysengdata
from .m7tdeploymentm7tcustomnonprod import m7tdeploymentm7tcustomnonprod
from .m7tdeploymentm7tdeployfullnonprod import m7tdeploymentm7tdeployfullnonprod
from .m7tdeploymentm7tcustomprod import m7tdeploymentm7tcustomprod
from .m7tdeploymentm7tdeployfullprod import m7tdeploymentm7tdeployfullprod
from .sysengdatachange import sysengdatachange
from .kpidata import kpidata
# Run ``configure_mappers`` after defining all of the models to ensure
# all relationships can be setup.
configure_mappers()


def get_db_engine(config: ConfigParser):
    db_config = config["database"]

    # PostgreSQL
    if db_config["type"] == "postgres":
        url = "postgresql://{username}:{password}@{host}:{port}/{db}".format(
            username=db_config["username"],
            password=db_config["password"],
            host=db_config["host"],
            port=db_config["port"],
            db=db_config["database"],
        )
        engine = create_engine(
            url=url,
            encoding="utf-8",
        )
    # Local SQLite for testing
    elif db_config["type"] == "sqlite":
        engine = create_engine(
            "sqlite://{file}".format(file=db_config["file"]),
            encoding="utf-8",
        )
    else:
        raise ValueError("Invalid database type")
    return engine


def get_db_session_maker(config: ConfigParser):
    return sessionmaker(bind=get_db_engine(config))
