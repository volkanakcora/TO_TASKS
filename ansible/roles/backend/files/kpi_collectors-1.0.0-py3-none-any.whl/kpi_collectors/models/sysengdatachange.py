from sqlalchemy import (
    Boolean,
    Column,
    DateTime,
    Index,
    Integer,
    Text,
    String,
)

from .meta import Base


class sysengdatachange(Base):
    __tablename__ = "sysengdatachange"
    id = Column(Integer, primary_key=True)

    key = Column(String)
    summary = Column(String)
    issuetype = Column(String)
    status = Column(String)
    project = Column(String)
    priority = Column(String)
    assignee = Column(String)
    created = Column(DateTime)
    labels = Column(String)
    description = Column(String)
    resolution = Column(String)
    resolutiondate = Column(DateTime)
    statusdescription = Column(String)
    resolved = Column(DateTime)
    project = Column(String)
    epsenvironment = Column(String)
    epstennant = Column(String)
    servicecatalogue = Column(Text)
