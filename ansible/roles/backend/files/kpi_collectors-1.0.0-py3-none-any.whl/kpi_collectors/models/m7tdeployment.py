from sqlite3 import Timestamp
from sqlalchemy import (
    Boolean,
    Column,
    DateTime,
    Index,
    Integer,
    Text,
    String,
)

from .meta import Base


class m7tdeployment(Base):
    __tablename__ = "m7tdeployment"
    id = Column(Integer, primary_key=True)

    m7env = Column(String(32), nullable=False, unique=False)
    seconds = Column(Integer)
    results = Column(Text)
    Timestamp = Column(DateTime)
