from sqlite3 import Timestamp
from sqlalchemy import (
    Boolean,
    Column,
    DateTime,
    Index,
    Integer,
    Text,
    String,
)

from .meta import Base


class xbiddash(Base):
    __tablename__ = "xbiddash"
    timestamp = Column(DateTime, primary_key=True)

    maintenance = Column(Integer)
    development = Column(Integer)
