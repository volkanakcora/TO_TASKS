from sqlalchemy import (
    Boolean,
    Column,
    DateTime,
    Index,
    Integer,
    Text,
    String,
)

from .meta import Base


class m7tdeploymentm7tdeployfullprod(Base):
    __tablename__ = "m7tdeploymentm7tdeployfullprod"
    id = Column(Integer, primary_key=True)

    m7env = Column(String(32), nullable=False, unique=False)
    seconds = Column(Integer)
    results = Column(Text)
    Timestamp = Column(DateTime)
    deployAmq = Column(String)
    deployApa = Column(String)
    deployHap = Column(String)
    deployApp = Column(String)
