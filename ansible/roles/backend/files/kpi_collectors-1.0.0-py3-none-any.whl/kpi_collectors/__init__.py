from argparse import ArgumentParser
from ast import arg
from configparser import ConfigParser
from functools import wraps
import imp
from multiprocessing.sharedctypes import Value
from textwrap import wrap
import time
import numpy as np
import pandas as pd
import schedule
from .collectors.kpi_jira_etl import jiracollectorkpimain
from .collectors.jenkin import jenkingcollector
from .models import get_db_session_maker
from .collectors.jira_etl import jiracollectorymain
from .alembic import *


# def run_collector(args):
#     jenkins_collector = jenkingcollector(args.config)
#     jenkins_collector.run()
#     #jira_collector = jiracollectorymain(args.config)
#     #jira_collector.run()

#     print('Second part reports have been generated')


def get_args():
    parser = ArgumentParser()
    parser.add_argument("config")
    return parser.parse_args()


def get_config(config_path: str):
    config = ConfigParser()
    config.read(config_path)
    return config


def main():
    """Entrypoint of application."""
    cli_args = get_args()
    config = get_config(cli_args.config)
    db_session_maker = get_db_session_maker(config)

    def wrap_run_collector(collector):
        """This function wraps a collector into a database transaction."""

        @wraps(collector)
        def wrapper(*args, **kwargs):
            # Start the database transaction
            db_session = db_session_maker()
            try:
                collector(db_session, config).run()
            except Exception:  # On error rollback changes made to db
                db_session.rollback()
                raise
            else:  # If no error happened commit changes to db
                db_session.commit()

        return wrapper

    # Schedule jobs
    schedule.every().day.at("07:30").do(wrap_run_collector(jenkingcollector))
    schedule.every().day.at("08:30").do(wrap_run_collector(jiracollectorymain))
    schedule.every().day.at('09:00').do(wrap_run_collector(jiracollectorkpimain))

    # schedule.every().day.at("07:30").do(wrap_transaction(run_jenkins_collector), cli_args)
    # schedule.every().day.at("08:00").do(wrap_transaction(run_jira_collector), cli_args)
    # Infinit cycle for scheduler
    #schedule.run_all()

    while True:
        schedule.run_pending()
        time.sleep(1)


if __name__ == "__main__":
    main()
