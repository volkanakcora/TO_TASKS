from operator import index
import time
from sqlalchemy import insert
from datetime import datetime
from pandas.core.algorithms import diff
from pprint import pprint
from sqlalchemy.exc import IntegrityError
from sqlalchemy import exists
import os
from requests import Session
import requests
import os
import numpy as np
import urllib
import json
import pandas as pd
from . import CollectorBase
from sqlalchemy import create_engine, engine
from . import etl_functions
from ..models import m7tdeployment
from ..models import m7tdeploymentseamless_new
from ..models import xbid
from ..models import m7tdeploymentm7tcustomnonprod
from ..models import m7tdeploymentm7tdeployfullnonprod
from ..models import m7tdeploymentm7tcustomprod
from ..models import m7tdeploymentm7tdeployfullprod

print("Scripts are running")

### XBID PROD DATA PROCESSING


class jenkingcollector(CollectorBase):
    def __init__(self, connection, config):
        super().__init__(connection, config)
        self.session = Session()
        self.session.auth = (
            self.config["jenkin"]["user"],
            self.config["jenkin"]["token"],
        )

    def run(self):
        # self.datagenerationforjenkinM7T_DEPLOY_UPGRADE()
        # self.datagenerationforjenkinM7T_deployfull()
        self.datagenerationforjenkindeploy_m7t_custom_nonprod()
        self.datagenerationforjenkindeploy_m7t_full_nonprod()
        self.datagenerationforjenkindeploy_m7t_custom_prod()
        self.datagenerationforjenkindeploy_m7t_full_prod()
        self.datagenerationforjenkinxbid()

    def datagenerationforjenkinxbid(self):

        server_xbid = requests.get(
            "https://englobjci1.deutsche-boerse.de/job/Operations/job/06-XBID/job/deploy_xbid_full/api/json?tree=allBuilds[actions[parameters[name,value]],duration,description,building,fullDisplayName,id,number,timestamp,result]&pretty=true",
            auth=(self.config["jenkin"]["user"], self.config["jenkin"]["token"]),
        )
        json_data_xbid = json.loads(server_xbid.text)
        json_data_XBID = pd.DataFrame(json_data_xbid)
        builds_XBID = json_data_XBID["allBuilds"].apply(pd.Series)

        # Get job info

        resp = self.session.get(
            "https://englobjci1.deutsche-boerse.de/job/Operations/job/06-XBID/job/deploy_xbid_full/api/json?tree=allBuilds[*]"
        )

        resp.raise_for_status()
        job = resp.json()
        XBID = []
        # Get info for each build
        for build in job["allBuilds"]:
            build_number = build["number"]
            # Get build details
            resp = self.session.get(f"{build['url']}/api/json?tree = allBuilds[*]")
            resp.raise_for_status()
            build_details = resp.json()
            # Find action "ParametersAction"
            for action in build_details["actions"]:
                if action.get("_class") == "hudson.model.ParametersAction":
                    parameters = {
                        param["name"]: param["value"] for param in action["parameters"]
                    }
                    break
            else:
                parameters = {}
            # print("===", build_number, "===")

            XBID.append(pd.Series(parameters))

        XBID = pd.DataFrame(XBID)
        print("XBID data retrieved")

        XBID["duration"] = builds_XBID["duration"]
        XBID["result"] = builds_XBID["result"]
        XBID["timestamp"] = builds_XBID["timestamp"]
        XBID["id"] = builds_XBID["id"]
        XBID = XBID[XBID.check == False]

        XBID["timestamp"] = etl_functions.timeconverter(XBID["timestamp"])
        XBID["duration"] = etl_functions.durationconverter(XBID["duration"])
        XBID["duration"] = pd.to_timedelta(XBID["duration"])
        XBID["Seconds"] = XBID["duration"].dt.total_seconds()
        XBID = XBID[["timestamp", "id", "result", "Seconds", "environment", "action"]]
        # XBID.to_csv('/home/oh856/XBIDKPIJENKINS.csv')
        # XBID.to_csv('~/aho/EnergyKPI/GENERATEKPI/DATA-DEPLOYMENT/XBIDKPIJENKINS.csv')
        # XBID = pd.read_csv('/home/oh856/XBIDKPIJENKINS.csv')
        XBID = pd.DataFrame(XBID)

        already_processed_ids = self.db.query(xbid).all()
        id = []

        for i in already_processed_ids:
            id.append(pd.Series(i.id))
        if id:
            id = pd.DataFrame(id)
            id.rename(columns={0: "id"}, inplace=True)
            XBID["id"] = XBID["id"].astype(str).astype(int)
            db = pd.merge(XBID, id, on="id")

            df_to_send_database = XBID[~XBID.id.isin(db.id)]
        else:
            df_to_send_database = XBID

        for _, data in df_to_send_database.iterrows():
            new_row_XBID = xbid(
                id=data["id"],
                xbidenv=data["environment"],
                seconds=data["Seconds"],
                timestamp=data["timestamp"],
                results=data["result"],
                action=data["action"],
            )

            self.db.add(new_row_XBID)
        print("Inserted new row!")

    def datagenerationforjenkinM7T_deployfull(self):

        server_m7t = requests.get(
            "https://englobjci1.deutsche-boerse.de/job/Energy-Operations/job/CD-Pipeline/job/M7T_deploy_full/api/json?tree=allBuilds%5Bactions%5Bparameters%5Bname,value%5D%5D,duration,description,building,fullDisplayName,id,number,timestamp,result%5D&pretty=true",
            auth=(self.config["jenkin"]["user"], self.config["jenkin"]["token"]),
        )
        json_data_M7TJ = json.loads(server_m7t.text)
        json_data_M7T = pd.DataFrame(json_data_M7TJ)
        builds_M7T = json_data_M7T["allBuilds"].apply(pd.Series)

        # Get job info
        resp = self.session.get(
            "https://englobjci1.deutsche-boerse.de/job/Energy-Operations/job/CD-Pipeline/job/M7T_deploy_full/api/json?tree=allBuilds[*]"
        )
        resp.raise_for_status()
        data = []
        job = resp.json()
        EH = []
        # Get info for each build
        for build in job["allBuilds"]:
            # Get build details
            resp = self.session.get(f"{build['url']}/api/json?tree = allBuilds[*]")
            resp.raise_for_status()
            build_details = resp.json()
            # Find action "ParametersAction"
            for action in build_details["actions"]:
                if action.get("_class") == "hudson.model.ParametersAction":
                    parameters = {
                        param["name"]: param["value"] for param in action["parameters"]
                    }
                    break
            else:
                parameters = {}
            # print("===", build_number, "===")
            EH.append(pd.Series(parameters))

        M7T = pd.DataFrame(EH)
        print("M7T DEPLOY data retrieved")

        M7T["duration"] = builds_M7T["duration"]
        M7T["result"] = builds_M7T["result"]
        M7T["timestamp"] = builds_M7T["timestamp"]
        M7T["id"] = builds_M7T["id"]
        M7T = M7T[M7T.check == False]

        M7T["timestamp"] = etl_functions.timeconverter(M7T["timestamp"])
        M7T["duration"] = etl_functions.durationconverter(M7T["duration"])
        M7T["duration"] = pd.to_timedelta(M7T["duration"])
        M7T["seconds"] = M7T["duration"].dt.total_seconds()
        # M7T.to_csv('/home/oh856/M7TDEPLOY.csv')
        # M7T.to_csv('~/aho/EnergyKPI/GENERATEKPI/DATA-DEPLOYMENT/M7TDEPLOY.csv')
        M7T = pd.DataFrame(
            M7T[["duration", "m7env", "id", "result", "seconds", "timestamp"]]
        )

        already_processed_ids = self.db.query(m7tdeployment).all()
        id = []

        for i in already_processed_ids:
            id.append(pd.Series(i.id))
        if id:
            id = pd.DataFrame(id)
            id.rename(columns={0: "id"}, inplace=True)
            M7T["id"] = M7T["id"].astype(str).astype(int)
            db = pd.merge(M7T, id, on="id")

            df_to_send_database = M7T[~M7T.id.isin(db.id)]
        else:
            df_to_send_database = M7T

        for _, data in df_to_send_database.iterrows():
            new_row_m7tdeploy = m7tdeployment(
                id=data["id"],
                m7env=data["m7env"],
                seconds=data["seconds"],
                results=data["result"],
                Timestamp=data["timestamp"],
            )

            self.db.add(new_row_m7tdeploy)
        print("Inserted new row!")

    def datagenerationforjenkinM7T_DEPLOY_UPGRADE(self):

        server_m7t_deploy_upgrade = requests.get(
            "https://englobjci1.deutsche-boerse.de/job/Energy-Operations/job/CD-Pipeline/job/M7T_deploy_upgrade/api/json?tree=allBuilds%5Bactions%5Bparameters%5Bname,value%5D%5D,duration,description,building,fullDisplayName,id,number,timestamp,result%5D&pretty=true",
            auth=(self.config["jenkin"]["user"], self.config["jenkin"]["token"]),
        )
        json_data_M7TDEPLOY = json.loads(server_m7t_deploy_upgrade.text)
        json_data_M7T_DEPLOY = pd.DataFrame(json_data_M7TDEPLOY)
        builds_M7T_DEPLOY = json_data_M7T_DEPLOY["allBuilds"].apply(pd.Series)

        # Get job info
        resp = self.session.get(
            "https://englobjci1.deutsche-boerse.de/job/Energy-Operations/job/CD-Pipeline/job/M7T_deploy_upgrade/api/json?tree=allBuilds[*]"
        )
        resp.raise_for_status()
        job = resp.json()
        M7T_deploy_upgrade = []
        # Get info for each build
        for build in job["allBuilds"]:
            build_number = build["number"]
            # Get build details
            resp = self.session.get(f"{build['url']}/api/json?tree = allBuilds[*]")
            resp.raise_for_status()
            build_details = resp.json()
            # Find action "ParametersAction"
            for action in build_details["actions"]:
                if action.get("_class") == "hudson.model.ParametersAction":
                    parameters = {
                        param["name"]: param["value"] for param in action["parameters"]
                    }
                    break
            else:
                parameters = {}
            # print("===", build_number, "===")

            M7T_deploy_upgrade.append(pd.Series(parameters))

        M7TDEPLOYUPGRADE = pd.DataFrame(M7T_deploy_upgrade)
        print("M7T deploy SEAMLESS data retrieved")

        M7TDEPLOYUPGRADE["duration"] = builds_M7T_DEPLOY["duration"]
        M7TDEPLOYUPGRADE["result"] = builds_M7T_DEPLOY["result"]
        M7TDEPLOYUPGRADE["timestamp"] = builds_M7T_DEPLOY["timestamp"]
        M7TDEPLOYUPGRADE["id"] = builds_M7T_DEPLOY["id"]
        M7TDEPLOYUPGRADE_V1 = M7TDEPLOYUPGRADE[M7TDEPLOYUPGRADE["check"] == False]

        M7TDEPLOYUPGRADE_V1["timestamp"] = etl_functions.timeconverter(
            M7TDEPLOYUPGRADE_V1["timestamp"]
        )
        M7TDEPLOYUPGRADE_V1["duration"] = etl_functions.durationconverter(
            M7TDEPLOYUPGRADE_V1["duration"]
        )
        M7TDEPLOYUPGRADE_V1["duration"] = pd.to_timedelta(
            M7TDEPLOYUPGRADE_V1["duration"]
        )
        M7TDEPLOYUPGRADE_V1["seconds"] = M7TDEPLOYUPGRADE_V1[
            "duration"
        ].dt.total_seconds()
        # M7TDEPLOYUPGRADE_V1.to_csv('/home/oh856/M7T_DEPLOY_UPGRADE_SEAMSLESS.csv')
        M7TDEPLOYUPGRADE_V2 = pd.DataFrame(
            M7TDEPLOYUPGRADE_V1[
                ["duration", "m7env", "id", "result", "seconds", "timestamp"]
            ]
        )

        already_processed_ids = self.db.query(m7tdeploymentseamless_new).all()
        id = []

        for i in already_processed_ids:
            id.append(pd.Series(i.id))

        if id:
            id = pd.DataFrame(id)
            id.rename(columns={0: "id"}, inplace=True)
            M7TDEPLOYUPGRADE_V2["id"] = (
                M7TDEPLOYUPGRADE_V2["id"].astype(str).astype(int)
            )
            db = pd.merge(M7TDEPLOYUPGRADE_V2, id, on="id")

            df_to_send_database = M7TDEPLOYUPGRADE_V2[
                ~M7TDEPLOYUPGRADE_V2.id.isin(db.id)
            ]
        else:
            df_to_send_database = M7TDEPLOYUPGRADE_V2

        try:
            for _, data in df_to_send_database.iterrows():
                new_row_m7tseamless = m7tdeploymentseamless_new(
                    id=data["id"],
                    m7env=data["m7env"],
                    seconds=data["seconds"],
                    results=data["result"],
                    Timestamp=data["timestamp"],
                )

                self.db.add(new_row_m7tseamless)
        except IntegrityError:
            print("row kipped")

        # Insert row into db

        print("Inserted new row!", m7tdeploymentseamless_new)

    def datagenerationforjenkindeploy_m7t_custom_nonprod(self):

        server_m7t_deploy_custom_nonprod = requests.get(
            "https://englobjci1.deutsche-boerse.de/job/Operations/job/04-M7T/job/deploy_m7t_custom/api/json?tree=allBuilds%5Bactions%5Bparameters%5Bname,value%5D%5D,duration,description,building,fullDisplayName,id,number,timestamp,result%5D&pretty=true",
            auth=(self.config["jenkin"]["user"], self.config["jenkin"]["token"]),
        )
        json_data_M7TDEPLOY_custom_nonprod = json.loads(
            server_m7t_deploy_custom_nonprod.text
        )
        json_data_M7TDEPLOY_custom_nonprod = pd.DataFrame(
            json_data_M7TDEPLOY_custom_nonprod
        )
        builds_M7T_DEPLOY_custom_nonprod = json_data_M7TDEPLOY_custom_nonprod[
            "allBuilds"
        ].apply(pd.Series)

        # Get job info
        resp = self.session.get(
            "https://englobjci1.deutsche-boerse.de/job/Operations/job/04-M7T/job/deploy_m7t_custom/api/json?tree=allBuilds[*]"
        )
        resp.raise_for_status()
        job = resp.json()
        deploy_m7t_custom_nonprod = []
        # Get info for each build
        for build in job["allBuilds"]:
            build_number = build["number"]
            # Get build details
            resp = self.session.get(f"{build['url']}/api/json?tree = allBuilds[*]")
            resp.raise_for_status()
            build_details = resp.json()
            # Find action "ParametersAction"
            for action in build_details["actions"]:
                if action.get("_class") == "hudson.model.ParametersAction":
                    parameters = {
                        param["name"]: param["value"] for param in action["parameters"]
                    }
                    break
            else:
                parameters = {}
            # print("===", build_number, "===")

            deploy_m7t_custom_nonprod.append(pd.Series(parameters))

        deploy_m7t_custom_nonprod = pd.DataFrame(deploy_m7t_custom_nonprod)
        print("M7T deploy SEAMLESS data retrieved")

        deploy_m7t_custom_nonprod["duration"] = builds_M7T_DEPLOY_custom_nonprod[
            "duration"
        ]
        deploy_m7t_custom_nonprod["result"] = builds_M7T_DEPLOY_custom_nonprod["result"]
        deploy_m7t_custom_nonprod["timestamp"] = builds_M7T_DEPLOY_custom_nonprod[
            "timestamp"
        ]
        deploy_m7t_custom_nonprod["id"] = builds_M7T_DEPLOY_custom_nonprod["id"]

        deploy_m7t_custom_nonprod_v1 = deploy_m7t_custom_nonprod[
            deploy_m7t_custom_nonprod["check"] == False
        ]

        deploy_m7t_custom_nonprod_v1["timestamp"] = etl_functions.timeconverter(
            deploy_m7t_custom_nonprod_v1["timestamp"]
        )
        deploy_m7t_custom_nonprod_v1["duration"] = etl_functions.durationconverter(
            deploy_m7t_custom_nonprod_v1["duration"]
        )
        deploy_m7t_custom_nonprod_v1["duration"] = pd.to_timedelta(
            deploy_m7t_custom_nonprod_v1["duration"]
        )
        deploy_m7t_custom_nonprod_v1["seconds"] = deploy_m7t_custom_nonprod_v1[
            "duration"
        ].dt.total_seconds()
        # M7TDEPLOYUPGRADE_V1.to_csv('/home/oh856/M7T_DEPLOY_UPGRADE_SEAMSLESS.csv')

        deploy_m7t_custom_nonprod_v2 = pd.DataFrame(
            deploy_m7t_custom_nonprod_v1[
                [
                    "duration",
                    "m7env",
                    "id",
                    "result",
                    "seconds",
                    "timestamp",
                    "deploy_apa",
                    "deploy_hap",
                    "deploy_cor",
                    "deploy_enq",
                    "deploy_rep",
                    "deploy_h2h",
                    "deploy_mtt",
                    "deploy_thr",
                    "deploy_pmi",
                    "deploy_bha",
                    "deploy_amq",
                    "deploy_cod",
                    "deploy_car",
                    "deploy_sta",
                    "deploy_hrv",
                ]
            ]
        )

        already_processed_ids = self.db.query(m7tdeploymentm7tcustomnonprod).all()
        id = []

        for i in already_processed_ids:
            id.append(pd.Series(i.id))

        if id:
            id = pd.DataFrame(id)
            id.rename(columns={0: "id"}, inplace=True)
            deploy_m7t_custom_nonprod_v2["id"] = (
                deploy_m7t_custom_nonprod_v2["id"].astype(str).astype(int)
            )
            db = pd.merge(deploy_m7t_custom_nonprod_v2, id, on="id")

            df_to_send_database = deploy_m7t_custom_nonprod_v2[
                ~deploy_m7t_custom_nonprod_v2.id.isin(db.id)
            ]
        else:
            df_to_send_database = deploy_m7t_custom_nonprod_v2

        try:
            for _, data in df_to_send_database.iterrows():
                new_row_m7tcustomnonprod = m7tdeploymentm7tcustomnonprod(
                    id=data["id"],
                    m7env=data["m7env"],
                    seconds=data["seconds"],
                    results=data["result"],
                    Timestamp=data["timestamp"],
                    deploy_apa=data["deploy_apa"],
                    deploy_hap=data["deploy_hap"],
                    deploy_cor=data["deploy_cor"],
                    deploy_enq=data["deploy_enq"],
                    deploy_rep=data["deploy_rep"],
                    deploy_h2h=data["deploy_h2h"],
                    deploy_mtt=data["deploy_mtt"],
                    deploy_thr=data["deploy_thr"],
                    deploy_pmi=data["deploy_pmi"],
                    deploy_bha=data["deploy_bha"],
                    deploy_amq=data["deploy_amq"],
                    deploy_cod=data["deploy_cod"],
                    deploy_car=data["deploy_car"],
                    deploy_sta=data["deploy_sta"],
                    deploy_hrv=data["deploy_hrv"],
                )

                self.db.add(new_row_m7tcustomnonprod)
        except IntegrityError:
            print("row kipped")

        # Insert row into db

        print("Inserted new row!", m7tdeploymentm7tcustomnonprod)

    def datagenerationforjenkindeploy_m7t_full_nonprod(self):

        server_m7t_deploy_full_nonprod = requests.get(
            "https://englobjci1.deutsche-boerse.de/job/Operations/job/04-M7T/job/deploy_m7t_full/api/json?tree=allBuilds%5Bactions%5Bparameters%5Bname,value%5D%5D,duration,description,building,fullDisplayName,id,number,timestamp,result%5D&pretty=true",
            auth=(self.config["jenkin"]["user"], self.config["jenkin"]["token"]),
        )
        json_data_M7TDEPLOY_full_nonprod = json.loads(
            server_m7t_deploy_full_nonprod.text
        )
        json_data_M7TDEPLOY_full_nonprod = pd.DataFrame(
            json_data_M7TDEPLOY_full_nonprod
        )
        builds_M7T_DEPLOY_full_nonprod = json_data_M7TDEPLOY_full_nonprod[
            "allBuilds"
        ].apply(pd.Series)

        # Get job info
        resp = self.session.get(
            "https://englobjci1.deutsche-boerse.de/job/Operations/job/04-M7T/job/deploy_m7t_full/api/json?tree=allBuilds[*]"
        )
        resp.raise_for_status()
        job = resp.json()
        deploy_m7t_deploy_m7t_full_nonprod = []
        # Get info for each build
        for build in job["allBuilds"]:
            build_number = build["number"]
            # Get build details
            resp = self.session.get(f"{build['url']}/api/json?tree = allBuilds[*]")
            resp.raise_for_status()
            build_details = resp.json()
            # Find action "ParametersAction"
            for action in build_details["actions"]:
                if action.get("_class") == "hudson.model.ParametersAction":
                    parameters = {
                        param["name"]: param["value"] for param in action["parameters"]
                    }
                    break
            else:
                parameters = {}
            # print("===", build_number, "===")

            deploy_m7t_deploy_m7t_full_nonprod.append(pd.Series(parameters))

        deploy_m7t_deploy_m7t_full_nonprod = pd.DataFrame(
            deploy_m7t_deploy_m7t_full_nonprod
        )
        print("M7T deploy SEAMLESS data retrieved")

        deploy_m7t_deploy_m7t_full_nonprod["duration"] = builds_M7T_DEPLOY_full_nonprod[
            "duration"
        ]
        deploy_m7t_deploy_m7t_full_nonprod["result"] = builds_M7T_DEPLOY_full_nonprod[
            "result"
        ]
        deploy_m7t_deploy_m7t_full_nonprod[
            "timestamp"
        ] = builds_M7T_DEPLOY_full_nonprod["timestamp"]
        deploy_m7t_deploy_m7t_full_nonprod["id"] = builds_M7T_DEPLOY_full_nonprod["id"]

        deploy_m7t_deploy_m7t_full_nonprod_v1 = deploy_m7t_deploy_m7t_full_nonprod[
            deploy_m7t_deploy_m7t_full_nonprod["check"] == False
        ]

        deploy_m7t_deploy_m7t_full_nonprod_v1["timestamp"] = etl_functions.timeconverter(
            deploy_m7t_deploy_m7t_full_nonprod_v1["timestamp"]
        )
        deploy_m7t_deploy_m7t_full_nonprod_v1["duration"] = etl_functions.durationconverter(
            deploy_m7t_deploy_m7t_full_nonprod_v1["duration"]
        )
        deploy_m7t_deploy_m7t_full_nonprod_v1["duration"] = pd.to_timedelta(
            deploy_m7t_deploy_m7t_full_nonprod_v1["duration"]
        )
        deploy_m7t_deploy_m7t_full_nonprod_v1[
            "seconds"
        ] = deploy_m7t_deploy_m7t_full_nonprod_v1["duration"].dt.total_seconds()
        # M7TDEPLOYUPGRADE_V1.to_csv('/home/oh856/M7T_DEPLOY_UPGRADE_SEAMSLESS.csv')

        deploy_m7t_deploy_m7t_full_nonprod_v2 = pd.DataFrame(
            deploy_m7t_deploy_m7t_full_nonprod_v1[
                [
                    "duration",
                    "m7env",
                    "id",
                    "result",
                    "seconds",
                    "timestamp",
                    "deployAmq",
                    "deployApa",
                    "deployHap",
                    "deployApp",
                ]
            ]
        )

        already_processed_ids = self.db.query(m7tdeploymentm7tdeployfullnonprod).all()
        id = []

        for i in already_processed_ids:
            id.append(pd.Series(i.id))

        if id:
            id = pd.DataFrame(id)
            id.rename(columns={0: "id"}, inplace=True)
            deploy_m7t_deploy_m7t_full_nonprod_v2["id"] = (
                deploy_m7t_deploy_m7t_full_nonprod_v2["id"].astype(str).astype(int)
            )
            db = pd.merge(deploy_m7t_deploy_m7t_full_nonprod_v2, id, on="id")

            df_to_send_database = deploy_m7t_deploy_m7t_full_nonprod_v2[
                ~deploy_m7t_deploy_m7t_full_nonprod_v2.id.isin(db.id)
            ]
        else:
            df_to_send_database = deploy_m7t_deploy_m7t_full_nonprod_v2

        try:
            for _, data in df_to_send_database.iterrows():
                new_row_m7tdeployfullnonprod = m7tdeploymentm7tdeployfullnonprod(
                    id=data["id"],
                    m7env=data["m7env"],
                    seconds=data["seconds"],
                    results=data["result"],
                    Timestamp=data["timestamp"],
                    deployAmq=data["deployAmq"],
                    deployApa=data["deployApa"],
                    deployHap=data["deployHap"],
                    deployApp=data["deployApp"],
                )

                self.db.add(new_row_m7tdeployfullnonprod)
        except IntegrityError:
            print("row kipped")

        # Insert row into db

        print("Inserted new row!", m7tdeploymentm7tdeployfullnonprod)

    def datagenerationforjenkindeploy_m7t_custom_prod(self):

        server_m7t_deploy_custom_prod = requests.get(
            "https://englobjci1.deutsche-boerse.de/job/Operations/job/04-M7T/job/deploy_prod/job/deploy_m7t_custom_prod/api/json?tree=allBuilds%5Bactions%5Bparameters%5Bname,value%5D%5D,duration,description,building,fullDisplayName,id,number,timestamp,result%5D&pretty=true",
            auth=(self.config["jenkin"]["user"], self.config["jenkin"]["token"]),
        )
        json_data_M7TDEPLOY_custom_prod = json.loads(server_m7t_deploy_custom_prod.text)
        json_data_M7TDEPLOY_custom_prod = pd.DataFrame(json_data_M7TDEPLOY_custom_prod)
        builds_M7T_DEPLOY_custom_prod = json_data_M7TDEPLOY_custom_prod[
            "allBuilds"
        ].apply(pd.Series)

        # Get job info
        resp = self.session.get(
            "https://englobjci1.deutsche-boerse.de/job/Operations/job/04-M7T/job/deploy_prod/job/deploy_m7t_custom_prod/api/json?tree=allBuilds[*]"
        )
        resp.raise_for_status()
        job = resp.json()
        deploy_m7t_custom_prod = []
        # Get info for each build
        for build in job["allBuilds"]:
            build_number = build["number"]
            # Get build details
            resp = self.session.get(f"{build['url']}/api/json?tree = allBuilds[*]")
            resp.raise_for_status()
            build_details = resp.json()
            # Find action "ParametersAction"
            for action in build_details["actions"]:
                if action.get("_class") == "hudson.model.ParametersAction":
                    parameters = {
                        param["name"]: param["value"] for param in action["parameters"]
                    }
                    break
            else:
                parameters = {}
            # print("===", build_number, "===")

            deploy_m7t_custom_prod.append(pd.Series(parameters))

        deploy_m7t_custom_prod = pd.DataFrame(deploy_m7t_custom_prod)
        print("M7T deploy SEAMLESS data retrieved")

        deploy_m7t_custom_prod["duration"] = builds_M7T_DEPLOY_custom_prod["duration"]
        deploy_m7t_custom_prod["result"] = builds_M7T_DEPLOY_custom_prod["result"]
        deploy_m7t_custom_prod["timestamp"] = builds_M7T_DEPLOY_custom_prod["timestamp"]
        deploy_m7t_custom_prod["id"] = builds_M7T_DEPLOY_custom_prod["id"]

        deploy_m7t_custom_prod_v1 = deploy_m7t_custom_prod[
            deploy_m7t_custom_prod["check"] == False
        ]

        deploy_m7t_custom_prod_v1["timestamp"] = etl_functions.timeconverter(
            deploy_m7t_custom_prod_v1["timestamp"]
        )
        deploy_m7t_custom_prod_v1["duration"] = etl_functions.durationconverter(
            deploy_m7t_custom_prod_v1["duration"]
        )
        deploy_m7t_custom_prod_v1["duration"] = pd.to_timedelta(
            deploy_m7t_custom_prod_v1["duration"]
        )
        deploy_m7t_custom_prod_v1["seconds"] = deploy_m7t_custom_prod_v1[
            "duration"
        ].dt.total_seconds()
        # M7TDEPLOYUPGRADE_V1.to_csv('/home/oh856/M7T_DEPLOY_UPGRADE_SEAMSLESS.csv')

        deploy_m7t_custom_prod_v2 = pd.DataFrame(
            deploy_m7t_custom_prod_v1[
                [
                    "duration",
                    "m7env",
                    "id",
                    "result",
                    "seconds",
                    "timestamp",
                    "deploy_apa",
                    "deploy_hap",
                    "deploy_cor",
                    "deploy_enq",
                    "deploy_rep",
                    "deploy_h2h",
                    "deploy_mtt",
                    "deploy_thr",
                    "deploy_pmi",
                    "deploy_bha",
                    "deploy_amq",
                    "deploy_cod",
                    "deploy_car",
                    "deploy_sta",
                    "deploy_hrv",
                ]
            ]
        )

        already_processed_ids = self.db.query(m7tdeploymentm7tcustomprod).all()
        id = []

        for i in already_processed_ids:
            id.append(pd.Series(i.id))

        if id:
            id = pd.DataFrame(id)
            id.rename(columns={0: "id"}, inplace=True)
            deploy_m7t_custom_prod_v2["id"] = (
                deploy_m7t_custom_prod_v2["id"].astype(str).astype(int)
            )
            db = pd.merge(deploy_m7t_custom_prod_v2, id, on="id")

            df_to_send_database = deploy_m7t_custom_prod_v2[
                ~deploy_m7t_custom_prod_v2.id.isin(db.id)
            ]
        else:
            df_to_send_database = deploy_m7t_custom_prod_v2

        try:
            for _, data in df_to_send_database.iterrows():
                new_row_m7tcustomprod = m7tdeploymentm7tcustomprod(
                    id=data["id"],
                    m7env=data["m7env"],
                    seconds=data["seconds"],
                    results=data["result"],
                    Timestamp=data["timestamp"],
                    deploy_apa=data["deploy_apa"],
                    deploy_hap=data["deploy_hap"],
                    deploy_cor=data["deploy_cor"],
                    deploy_enq=data["deploy_enq"],
                    deploy_rep=data["deploy_rep"],
                    deploy_h2h=data["deploy_h2h"],
                    deploy_mtt=data["deploy_mtt"],
                    deploy_thr=data["deploy_thr"],
                    deploy_pmi=data["deploy_pmi"],
                    deploy_bha=data["deploy_bha"],
                    deploy_amq=data["deploy_amq"],
                    deploy_cod=data["deploy_cod"],
                    deploy_car=data["deploy_car"],
                    deploy_sta=data["deploy_sta"],
                    deploy_hrv=data["deploy_hrv"],
                )

                self.db.add(new_row_m7tcustomprod)
        except IntegrityError:
            print("row kipped")

        # Insert row into db

        print("Inserted new row!", m7tdeploymentm7tcustomprod)

    def datagenerationforjenkindeploy_m7t_full_prod(self):

        server_m7t_deploy_full_prod = requests.get(
            "https://englobjci1.deutsche-boerse.de/job/Operations/job/04-M7T/job/deploy_prod/job/deploy_m7t_full_prod/api/json?tree=allBuilds%5Bactions%5Bparameters%5Bname,value%5D%5D,duration,description,building,fullDisplayName,id,number,timestamp,result%5D&pretty=true",
            auth=(self.config["jenkin"]["user"], self.config["jenkin"]["token"]),
        )
        json_data_M7TDEPLOY_full_prod = json.loads(server_m7t_deploy_full_prod.text)
        json_data_M7TDEPLOY_full_prod = pd.DataFrame(json_data_M7TDEPLOY_full_prod)
        builds_M7T_DEPLOY_full_prod = json_data_M7TDEPLOY_full_prod["allBuilds"].apply(
            pd.Series
        )

        # Get job info
        resp = self.session.get(
            "https://englobjci1.deutsche-boerse.de/job/Operations/job/04-M7T/job/deploy_prod/job/deploy_m7t_full_prod/api/json?tree=allBuilds[*]"
        )
        resp.raise_for_status()
        job = resp.json()
        deploy_m7t_deploy_m7t_full_prod = []
        # Get info for each build
        for build in job["allBuilds"]:
            build_number = build["number"]
            # Get build details
            resp = self.session.get(f"{build['url']}/api/json?tree = allBuilds[*]")
            resp.raise_for_status()
            build_details = resp.json()
            # Find action "ParametersAction"
            for action in build_details["actions"]:
                if action.get("_class") == "hudson.model.ParametersAction":
                    parameters = {
                        param["name"]: param["value"] for param in action["parameters"]
                    }
                    break
            else:
                parameters = {}
            # print("===", build_number, "===")

            deploy_m7t_deploy_m7t_full_prod.append(pd.Series(parameters))

        deploy_m7t_deploy_m7t_full_prod = pd.DataFrame(deploy_m7t_deploy_m7t_full_prod)
        print("M7T deploy SEAMLESS data retrieved")

        deploy_m7t_deploy_m7t_full_prod["duration"] = builds_M7T_DEPLOY_full_prod[
            "duration"
        ]
        deploy_m7t_deploy_m7t_full_prod["result"] = builds_M7T_DEPLOY_full_prod[
            "result"
        ]
        deploy_m7t_deploy_m7t_full_prod["timestamp"] = builds_M7T_DEPLOY_full_prod[
            "timestamp"
        ]
        deploy_m7t_deploy_m7t_full_prod["id"] = builds_M7T_DEPLOY_full_prod["id"]
        deploy_m7t_deploy_m7t_full_prod_v1 = deploy_m7t_deploy_m7t_full_prod[
            deploy_m7t_deploy_m7t_full_prod["check"] == False
        ]

        deploy_m7t_deploy_m7t_full_prod_v1["timestamp"] = etl_functions.timeconverter(
            deploy_m7t_deploy_m7t_full_prod_v1["timestamp"]
        )
        deploy_m7t_deploy_m7t_full_prod_v1["duration"] = etl_functions.durationconverter(
            deploy_m7t_deploy_m7t_full_prod_v1["duration"]
        )
        deploy_m7t_deploy_m7t_full_prod_v1["duration"] = pd.to_timedelta(
            deploy_m7t_deploy_m7t_full_prod_v1["duration"]
        )
        deploy_m7t_deploy_m7t_full_prod_v1[
            "seconds"
        ] = deploy_m7t_deploy_m7t_full_prod_v1["duration"].dt.total_seconds()
        # M7TDEPLOYUPGRADE_V1.to_csv('/home/oh856/M7T_DEPLOY_UPGRADE_SEAMSLESS.csv')

        deploy_m7t_deploy_m7t_full_prod_v2 = pd.DataFrame(
            deploy_m7t_deploy_m7t_full_prod_v1[
                [
                    "duration",
                    "m7env",
                    "id",
                    "result",
                    "seconds",
                    "timestamp",
                    "deployAmq",
                    "deployApa",
                    "deployHap",
                    "deployApp",
                ]
            ]
        )

        already_processed_ids = self.db.query(m7tdeploymentm7tdeployfullprod).all()
        id = []

        for i in already_processed_ids:
            id.append(pd.Series(i.id))

        if id:
            id = pd.DataFrame(id)
            id.rename(columns={0: "id"}, inplace=True)
            deploy_m7t_deploy_m7t_full_prod_v2["id"] = (
                deploy_m7t_deploy_m7t_full_prod_v2["id"].astype(str).astype(int)
            )
            db = pd.merge(deploy_m7t_deploy_m7t_full_prod_v2, id, on="id")

            df_to_send_database = deploy_m7t_deploy_m7t_full_prod_v2[
                ~deploy_m7t_deploy_m7t_full_prod_v2.id.isin(db.id)
            ]
        else:
            df_to_send_database = deploy_m7t_deploy_m7t_full_prod_v2

        try:
            for _, data in df_to_send_database.iterrows():
                new_row_m7tdeployfullprod = m7tdeploymentm7tdeployfullprod(
                    id=data["id"],
                    m7env=data["m7env"],
                    seconds=data["seconds"],
                    results=data["result"],
                    Timestamp=data["timestamp"],
                    deployAmq=data["deployAmq"],
                    deployApa=data["deployApa"],
                    deployHap=data["deployHap"],
                    deployApp=data["deployApp"],
                )

                self.db.add(new_row_m7tdeployfullprod)
        except IntegrityError:
            print("row kipped")

        # Insert row into db

        print("Inserted new row!", m7tdeploymentm7tdeployfullprod)


