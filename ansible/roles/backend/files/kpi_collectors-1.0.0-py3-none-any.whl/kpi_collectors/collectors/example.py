# from random import randint

# from . import CollectorBase
# from ..models import ExampleTable


# class ExampleCollector(CollectorBase):

#     def run(self):
#         # Does not collect anything. So just insert fake data into the db.

#         # Create new "Row"
#         new_row = ExampleTable(
#             name=str(randint(1000, 9999)),
#             age=20,
#         )
#         # Insert row into db
#         self.db.add(new_row)
#         print("Inserted new row!")

#         # Show current rows
#         count = self.db.query(ExampleTable).count()
#         print("Query all existing rows. Count:", count)
#         for example in self.db.query(ExampleTable).filter(ExampleTable.age > 10):
#             print(example.id, example.name, example.age, example.comment)

#         # Delete all rows if count is 5
#         if count >= 5:
#             print("Deleting all rows.")
#             for example in self.db.query(ExampleTable):
#                 self.db.delete(example)
