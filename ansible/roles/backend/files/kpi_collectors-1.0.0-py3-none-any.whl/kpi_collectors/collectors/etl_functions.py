import numpy as np
import pandas as pd


def timeconverter(data):
    data = pd.to_datetime(data, unit="ms")
    data = data.apply(lambda x: x.date())
    return data


def durationconverter(data):
    data = pd.to_datetime(data, unit="ms")
    data = data.dt.strftime("%H:%M:%S")
    return data



def parsingdatawithtwolevel(data, data_column, df_to_append, column_name):
    for i in pd.Series(data[data_column]):
        try:
            print(df_to_append.append(i[0][column_name]))
        except IndexError:
            print(df_to_append.append("Na"))


def parsingdatawiththreelevel(data, data_column, df_to_append):
    for i in pd.Series(data[data_column]):
        try:
            print(df_to_append.append(i[0]["remainingTime"]["friendly"]))
        except:
            print(df_to_append.append("Na"))


def processed_id_selection(already_processed_ids, syseng_result):
    id = []
    for i in already_processed_ids:
        id.append(pd.Series(i.id))
    if id:

        id = pd.DataFrame(id)
        id.rename(columns={0: "Issue id"}, inplace=True)
        syseng_result["Issue id"] = (
            syseng_result["Issue id"].astype(str).astype(int)
        )
        db = pd.merge(syseng_result, id, on="Issue id")
        df_to_send_database = syseng_result[
            ~syseng_result["Issue id"].isin(db["Issue id"])
        ]
    else:
        df_to_send_database = syseng_result
        
    return df_to_send_database