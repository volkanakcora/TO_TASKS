from . import CollectorBase
from . import etl_functions
import pandas as pd
import numpy as np
from ..models import sysengdata
from jira.client import JIRA
from . import CollectorBase
from requests import Session
from ..models import sysengdatachange  
from .etl_functions import parsingdatawiththreelevel
from .etl_functions import parsingdatawithtwolevel
from .etl_functions import processed_id_selection

#### TO-DO FIX SYSENG SCRIPT, AND ADD CRON ANSIBLE MODULES.
class jiracollectorymain(CollectorBase):
    def __init__(self, connection, config):
        super().__init__(connection, config)
        self.session = Session()
        self.session.auth = self.config["jira"]["apikey"]
        options = {
            "server": "https://jira.deutsche-boerse.com/",
            "client_cert": "/opt/kpi/backend/newfile.pem",
        }
        self.jira = JIRA(
            options,
            proxies={
                "http": "webproxy.deutsche-boerse.de:8080",
                "https": "webproxy.deutsche-boerse.de:8080",
            },
            token_auth=self.config["jira"]["apikey"],
        )

   
    def run(self):
        #Calling runs!    
        syseng_result_change = self.sysengchange()
        syseng_result = self.syseng()
           
    def syseng(self):

        syseng_slide = ("""project =  "Energy Systems Engineering EXTERNAL" AND type in (Incident, Problem) AND resolution not in ("Won't Fix", "Won't Do", Rejected, Declined, Duplicate) AND request-channel-type = portal  AND status not in ( "REJECTED") """)
        syseng_result = pd.DataFrame()
        syseng = self.jira.search_issues(syseng_slide, maxResults=500)
        for issue in syseng:
            d = {
                "Summary": str(issue.fields.summary),
                "Issue Key": issue.key,
                "Issue id": issue.id,
                "Issue Type": str(issue.fields.issuetype.name),
                "status": str(issue.fields.status.name),
                "project": str(issue.fields.project),
                "priority": str(issue.fields.priority.name),
                "assignee": str(issue.fields.assignee),
                "created": str(issue.fields.created),
                "labels": str(issue.fields.labels),
                "description": str(issue.fields.description),
                "resolution": str(issue.fields.resolution),
                "resolved": str(issue.fields.resolutiondate),
                'EPS Environments': issue.raw['fields']['customfield_13957'],
                'EPS Tennant Application': str(issue.fields.customfield_13958),
                'Service Types': str(issue.fields.customfield_13952),
                "status_description": str(issue.fields.status.description),
                "updated": str(issue.fields.updated),
                "timetofirstresponse": issue.raw["fields"]["customfield_11261"][
                    "completedCycles"
                ],
                "timetoresolution": issue.raw["fields"]["customfield_11260"][
                    "completedCycles"
                ],
            }
            syseng_result = syseng_result.append(d, ignore_index=True)
        syseng_result = pd.DataFrame(syseng_result)
        epsenv = []
        timetofirstresponse = []
        response_breahced = []
        resolution_breached = []
        resolution = []



        #time to response ETL
        parsingdatawithtwolevel(syseng_result,'timetofirstresponse', response_breahced, "breached")
        parsingdatawiththreelevel(syseng_result, 'timetofirstresponse', timetofirstresponse)
        
        syseng_result["firstresponsebreached"] = response_breahced
        syseng_result["timetofirstresponse"] = timetofirstresponse

        #time to response ETL
        parsingdatawithtwolevel(syseng_result,'timetoresolution', resolution_breached, "breached")
        parsingdatawiththreelevel(syseng_result, 'timetoresolution', resolution)
        
        syseng_result["resolutionbreached"] = resolution_breached
        syseng_result["timetoresolution"] = resolution

        #eps environment ETL
        #parsingdatawithtwolevel(syseng_result,'EPS Environments', epsenv, "value")
        for i in pd.Series(syseng_result['EPS Environments']):
            try:
                print(epsenv.append(i[0]["value"]))
            except:
                print(epsenv.append("Na"))
        syseng_result['EPS Environment'] = epsenv

        #DataFrame preparation
        syseng_result['ServiceType'] = pd.DataFrame(syseng_result['Service Types'])
        print('this is latest service type:', syseng_result['ServiceType'])
        print(syseng_result)


        # SYSENG DATA
        #Database processing for SYSENG data
        already_processed_ids = self.db.query(sysengdata).all()
        df_to_send_database = processed_id_selection(already_processed_ids, syseng_result)
        print("this is the final version of sysengdata before it's pushed to db: ", df_to_send_database)

        for _, data in df_to_send_database.iterrows():
            new_row_syseng = sysengdata(
                id=data["Issue id"],
                key=data["Issue Key"],
                summary=data["Summary"],
                issuetype=data["Issue Type"],
                status=data["status"],
                project=data["project"],
                priority=data["priority"],
                assignee=data["assignee"],
                created=data["created"],
                labels=data["labels"],
                description=data["description"],
                resolution=data["resolution"],
                resolutiondate=data["resolved"],
                statusdescription=data["status_description"],
                timetofirstresponse=data["timetofirstresponse"],
                timetoresolution=data["timetoresolution"],
                firstresponsebreached=data["firstresponsebreached"],
                resolutionbreached=data["resolutionbreached"],
                epsenvironment = data['EPS Environment'],
                epstennant = data['EPS Tennant Application'],
                servicetype = data['ServiceType'],
            )

            self.db.add(new_row_syseng)

            # Insert row into db
        print("Inserted new row!")




    def sysengchange(self):

        syseng_slide_change = ("""project =  "Energy Systems Engineering EXTERNAL" AND type in (Change,Task) AND resolution not in ("Won't Fix", "Won't Do", Rejected, Declined, Duplicate) AND request-channel-type = portal  
 """)
        syseng_result_change = pd.DataFrame()
        syseng = self.jira.search_issues(syseng_slide_change, maxResults=500)
        for issue in syseng:
            d = {
                
                "Summary": str(issue.fields.summary),
                "Issue Key": issue.key,
                "Issue id": issue.id,
                "Issue Type": str(issue.fields.issuetype.name),
                "status": str(issue.fields.status.name),
                "project": str(issue.fields.project),
                "priority": str(issue.fields.priority.name),
                "assignee": str(issue.fields.assignee),
                "created": str(issue.fields.created),
                "labels": str(issue.fields.labels),
                "description": str(issue.fields.description),
                "resolution": str(issue.fields.resolution),
                "resolved": str(issue.fields.resolutiondate),
                'EPS Environments': issue.raw['fields']['customfield_13957'],
                'EPS Tennant Application': str(issue.fields.customfield_13958),
                'Service Catalogue': str(issue.fields.customfield_13705),
                "status_description": str(issue.fields.status.description),
                "updated": str(issue.fields.updated),
               
            }
            syseng_result_change = syseng_result_change.append(d, ignore_index=True)
        syseng_result_change = pd.DataFrame(syseng_result_change)
        epsenvchange = []
      

        #EPS Environment ETL
        #parsingdatawithtwolevel(syseng_result_change,'EPS Environments', epsenvchange, "value")
        for i in pd.Series(syseng_result_change['EPS Environments']):
            try:
                print(epsenvchange.append(i[0]["value"]))
            except:
                print(epsenvchange.append("Na"))
        syseng_result_change['EPS Environment'] = epsenvchange

        #SYSENG DATA CHANGE 
        #Database processing for SYSENG data
        already_processed_ids = self.db.query(sysengdatachange).all()
        df_to_send_database = processed_id_selection(already_processed_ids, syseng_result_change)
        print("this is the final version of sysengchangedata before it's pushed to db: ", df_to_send_database)

        for _, data in df_to_send_database.iterrows():
            new_row_syseng = sysengdatachange(
                id=data["Issue id"],
                key=data["Issue Key"],
                summary=data["Summary"],
                issuetype=data["Issue Type"],
                status=data["status"],
                project=data["project"],
                priority=data["priority"],
                assignee=data["assignee"],
                created=data["created"],
                labels=data["labels"],
                description=data["description"],
                resolution=data["resolution"],
                resolutiondate=data["resolved"],
                statusdescription=data["status_description"],
                epsenvironment = data['EPS Environment'],
                epstennant = data['EPS Tennant Application'],
                servicecatalogue = data['Service Catalogue'],
            )

            self.db.add(new_row_syseng)
    
            # Insert row into db

        print("Inserted new row!")

        



