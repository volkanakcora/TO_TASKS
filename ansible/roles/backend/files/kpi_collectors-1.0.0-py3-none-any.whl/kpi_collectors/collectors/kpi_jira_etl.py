from . import CollectorBase
import pandas as pd
from jira.client import JIRA
from . import CollectorBase
from requests import Session
from ..models import kpidata
from .etl_functions import parsingdatawiththreelevel
from .etl_functions import parsingdatawithtwolevel
from .etl_functions import processed_id_selection

class jiracollectorkpimain(CollectorBase):
    def __init__(self, connection, config) -> None:
        super().__init__(connection, config)
        self.session = Session()
        self.session.auth = self.config["jira"]["apikey"]
        options = {
            "server": "https://jira.deutsche-boerse.com/",
            "client_cert": "/opt/kpi/backend/newfile.pem",
        }
        self.jira = JIRA(
            options,
            proxies={
                "http": "webproxy.deutsche-boerse.de:8080",
                "https": "webproxy.deutsche-boerse.de:8080",
            },
            token_auth=self.config["jira"]["apikey"],
        )

        

    def run(self):
        #call your runs!
        kpi = self.kpi()


    def kpi(self):

        kpi_slide = ("""project in  (service,"Service Management - XBID") AND Organizations in (EPEX, "BSP SouthPool",HUPX,TGE,Opcom,XBID-ALL,"EEX (M7A)",Amprion,RTE,Swissgrid,APG) AND issuetype in (incident,Problem) AND createdDate >= endOfYear(-1) AND resolution not in ("Not a Bug", Rejected, Duplicate, "Cannot Reproduce") AND status in (closed, done) AND reporter != ServiceDeskAutomation ORDER BY created DESC """)
        kpi_result = pd.DataFrame()
        kpi = self.jira.search_issues(kpi_slide, maxResults=500)
        for issue in kpi:
            d = {
                "Summary": str(issue.fields.summary),
                "Issue Key": issue.key,
                "Issue id": issue.id,
                "Issue Type": str(issue.fields.issuetype.name),
                "status": str(issue.fields.status.name),
                "project": str(issue.fields.project),
                "priority": str(issue.fields.priority.name),
                "assignee": str(issue.fields.assignee),
                "created": str(issue.fields.created),
                "labels": str(issue.fields.labels),
                "description": str(issue.fields.description),
                "resolution": str(issue.fields.resolution),
                "resolved": str(issue.fields.resolutiondate),
                "status_description": str(issue.fields.status.description),
                "updated": str(issue.fields.updated),
                "timetofirstresponse": issue.raw["fields"]["customfield_11261"][
                    "completedCycles"
                ],
                "timetoresolution": issue.raw["fields"]["customfield_11260"][
                    "completedCycles"
                ],
                'organization': issue.raw['fields']['customfield_11550'],

            }
            kpi_result = kpi_result.append(d, ignore_index=True)

        kpi_result = pd.DataFrame(kpi_result)

        #Object data parsing
        organization = []
        timetofirstresponse = []
        response_breahced = []
        resolution = []
        resolution_breached = []

        #timetofirstresponse ETL
        parsingdatawithtwolevel(kpi_result,'timetofirstresponse', response_breahced, "breached")
        parsingdatawiththreelevel(kpi_result, 'timetofirstresponse', timetofirstresponse)
        
        kpi_result["firstresponsebreached"] = response_breahced
        kpi_result["timetofirstresponse"] = timetofirstresponse
        
        #timetoresolution ETL
        parsingdatawithtwolevel(kpi_result,'timetoresolution', resolution_breached, "breached")
        parsingdatawiththreelevel(kpi_result, 'timetoresolution', resolution)

        kpi_result["resolutionbreached"] = resolution_breached
        kpi_result["timetoresolution"] = resolution

        #timetoresolution
        parsingdatawithtwolevel(kpi_result,'organization', organization, "name")
        kpi_result["Product"] = organization

        #KPI DATA
        #Database processing for KPI data
        already_processed_ids = self.db.query(kpidata).all()
        df_to_send_database = processed_id_selection(already_processed_ids, kpi_result)
        print("this is the final version of KPI before it's pushed to db: ", df_to_send_database)

        for _, data in df_to_send_database.iterrows():
            new_row_kpi = kpidata(
                id=data["Issue id"],
                key=data["Issue Key"],
                summary=data["Summary"],
                issuetype=data["Issue Type"],
                status=data["status"],
                project=data["project"],
                priority=data["priority"],
                assignee=data["assignee"],
                created=data["created"],
                labels=data["labels"],
                description=data["description"],
                resolution=data["resolution"],
                resolutiondate=data["resolved"],
                statusdescription=data["status_description"],
                timetofirstresponse=data["timetofirstresponse"],
                timetoresolution=data["timetoresolution"],
                firstresponsebreached=data["firstresponsebreached"],
                resolutionbreached=data["resolutionbreached"],
                product = data['Product'],
            )

            self.db.add(new_row_kpi)

            # Insert row into db
        print("Inserted new row!")



        


      