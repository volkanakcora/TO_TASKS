"""Base for collectors."""
from configparser import ConfigParser
from requests import Session


class CollectorBase:
    """Collector baseclass handling common functionality shared by all collectors."""

    def __init__(self, connection, config) -> None:
        self.db = connection
        self.config = config

    ##TODO for Volkan: The logical 'entrypoint' of your subclasses should be the run method. Currently they just have "random" names
    def run(self):
        """Placeholder method. Subclasses should override this method and implement the business logic in it."""
        raise NotImplementedError("sub classes should implement the run method")
